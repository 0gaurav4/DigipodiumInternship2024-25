import tkinter as tk
from tkinter import messagebox
import sqlite3

# Database setup
def setup_database():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Register user
def register_user(username, password):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        messagebox.showinfo("Success", "Registration successful!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Username already exists!")
    finally:
        conn.close()

# Login user
def login_user(username, password, window):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    if user:
        show_successful_login_page(window, username)
    else:
        messagebox.showerror("Error", "Invalid username or password.")

# Successful login page
def show_successful_login_page(window, username):
    window.destroy()
    success_window = tk.Tk()
    success_window.title("Welcome")
    success_window.attributes("-fullscreen", True)  # Full screen

    tk.Label(success_window, text=f"Welcome, {username}!", font=("Arial", 30)).pack(pady=50)

    tk.Button(success_window, text="Exit", font=("Arial", 20), command=success_window.destroy).pack(pady=20)

    success_window.mainloop()

# GUI setup
def create_login_window():
    def handle_login():
        username = username_entry.get()
        password = password_entry.get()
        if username and password:
            login_user(username, password, login_window)
        else:
            messagebox.showerror("Error", "Please fill in all fields.")

    def open_register_window():
        login_window.destroy()
        create_register_window()

    login_window = tk.Tk()
    login_window.title("Login")
    login_window.attributes("-fullscreen", True)  # Full screen

    tk.Label(login_window, text="Login", font=("Arial", 30)).pack(pady=20)

    tk.Label(login_window, text="Username:", font=("Arial", 20)).pack(pady=10)
    username_entry = tk.Entry(login_window, font=("Arial", 20))
    username_entry.pack(pady=10)

    tk.Label(login_window, text="Password:", font=("Arial", 20)).pack(pady=10)
    password_entry = tk.Entry(login_window, show="*", font=("Arial", 20))
    password_entry.pack(pady=10)

    tk.Button(login_window, text="Login", font=("Arial", 20), command=handle_login).pack(pady=20)
    tk.Button(login_window, text="Register", font=("Arial", 20), command=open_register_window).pack(pady=10)

    login_window.mainloop()

def create_register_window():
    def handle_register():
        username = username_entry.get()
        password = password_entry.get()
        if username and password:
            register_user(username, password)
        else:
            messagebox.showerror("Error", "Please fill in all fields.")

    def open_login_window():
        register_window.destroy()
        create_login_window()

    register_window = tk.Tk()
    register_window.title("Register")
    register_window.attributes("-fullscreen", True)  # Full screen

    tk.Label(register_window, text="Register", font=("Arial", 30)).pack(pady=20)

    tk.Label(register_window, text="Username:", font=("Arial", 20)).pack(pady=10)
    username_entry = tk.Entry(register_window, font=("Arial", 20))
    username_entry.pack(pady=10)

    tk.Label(register_window, text="Password:", font=("Arial", 20)).pack(pady=10)
    password_entry = tk.Entry(register_window, show="*", font=("Arial", 20))
    password_entry.pack(pady=10)

    tk.Button(register_window, text="Register", font=("Arial", 20), command=handle_register).pack(pady=20)
    tk.Button(register_window, text="Back to Login", font=("Arial", 20), command=open_login_window).pack(pady=10)

    register_window.mainloop()

# Main execution
if __name__ == "__main__":
    setup_database()
    create_login_window()



# python -m PyInstaller app.py
